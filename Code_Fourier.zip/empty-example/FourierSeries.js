 // circle 1
let theta =0;
let wave = [];


function setup()
{
	createCanvas(800,600);
	slider = createSlider(1,100);
	slider.position(300,500);
}

function draw()
{



	background(0);
	noFill();
	stroke(255,100);

	let x0 = 200;
	let y0 = 200;

	for (let i =0 ; i < slider.value() ; i++ )
	{
		let n = i * 2 + 1;
		let r = (100)*(4/(n*PI));
		

		ellipse(x0,y0,r*2);
		prevx = x0;
		prevy = y0;
		x0 += r * cos(n *theta);
		y0 += r * sin(n *theta);

		line(prevx,prevy,x0,y0); 
	}

	wave.unshift(y0);
	line(x0,y0,600,wave[0]);
	translate(600,0)
	
	beginShape();
	for (let i =0;i < wave.length ; i++ )
	{
		vertex(i,wave[i])
	}
	endShape();





	theta += 0.03;

}
